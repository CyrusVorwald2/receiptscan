//package com.example.receiptscanner;
//
//import android.app.Activity;
//import android.content.Intent;
//import android.os.Bundle;
//import android.view.MotionEvent;
//import android.view.View;
//
//public class ManualTrim extends Activity { 
//	@Override
//    public void onCreate(Bundle savedInstanceState) {         
//
//       super.onCreate(savedInstanceState);    
//       setContentView(R.layout.manual_trim);
//       //rest of the code
//       final View touchView = findViewById(R.id.touchView);
//       touchView.setOnTouchListener(new View.OnTouchListener() {
//           @Override
//           public boolean onTouch(View v, MotionEvent event) {
//               System.out.println("Touch coordinates : " +
//                   String.valueOf(event.getX()) + "x" + String.valueOf(event.getY()));
//                   return true;
//           }
//       });
//       
//       public void onDraw()
//    }
//	
//	 
//	 
//}

package com.example.receiptscanner;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import android.app.Activity;
import android.os.Bundle;




public class ManualTrim extends Activity {

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		MyView myView = new MyView(this);
		setContentView(myView);
		myView.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
//				myView.drawCircle();
				System.out.println("Touch coordinates : " +
						String.valueOf(event.getX()) + "x" + String.valueOf(event.getY()));
				return true;
			}
		});
	}


	public class MyView extends View {

		Paint paint;
		Path path;
		Canvas canvas;

		public MyView(Context context) {
			super(context);
			init();
		}

		public MyView(Context context, AttributeSet attrs) {
			super(context, attrs);
			init();
		}

		public MyView(Context context, AttributeSet attrs, int defStyle) {
			super(context, attrs, defStyle);
			init();
		}

		private void init(){
			paint = new Paint();
			paint.setColor(Color.BLUE);
			paint.setStrokeWidth(10);
			paint.setStyle(Paint.Style.STROKE);

		}

		@Override
		protected void onDraw(Canvas canvas) {
			// TODO Auto-generated method stub
			super.onDraw(canvas);
			this.canvas = canvas;

			paint.setStyle(Paint.Style.STROKE);
			canvas.drawCircle(50, 50, 30, paint);

			paint.setStyle(Paint.Style.FILL);
			canvas.drawCircle(300, 300, 200, paint);
			//drawCircle(cx, cy, radius, paint)

		}
		
		public void drawCircle(Canvas canvas) {
			
			paint.setStyle(Paint.Style.STROKE);
			canvas.drawCircle(100, 100, 30, paint);
		}

	}
}