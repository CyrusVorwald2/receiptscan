package com.example.receiptscanner;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class ResultsActivity extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) { 
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_results);
		
	}
	
	public void takePicture(View view) {
		
		Intent startNewActivityOpen = new Intent(this, CameraActivity.class);
		startActivity(startNewActivityOpen);
		
	}

}
