package com.example.receiptscanner;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class CameraActivity extends Activity {
	 @Override
     public void onCreate(Bundle savedInstanceState) {         

        super.onCreate(savedInstanceState);    
        setContentView(R.layout.activity_camera);
        //rest of the code
     }
	 
	 public void toResults(View view) {
		Intent startNewActivityOpen = new Intent(this, ResultsActivity.class);
		startActivity(startNewActivityOpen);
	 }
	 public void manualTrim(View view) {
		Intent startNewActivityOpen = new Intent(this, ManualTrim.class);
		startActivity(startNewActivityOpen);
	 }
}
